# TicketDesk — redacted source handout

This archive is a source handout with placeholder credentials. It does not contain the original deployment secrets. Application logic is retained; redacted values change authentication, signatures, and returned data where described below.

## Redacted values

The reporter password, displayed reporter credentials, and fallback flag are redacted.

`REDACTED` is a literal placeholder, not an instruction to automatically load the original value. Redacted hardcoded credentials and signing keys do not gain environment-variable overrides in this handout.

## Runtime differences

The demo login is `reporter` / `REDACTED`. `ADMIN_PASS` must still be supplied explicitly and is shared by the app and bot through Compose; no admin password is included. The fallback flag is `gctf26{REDACTED}`; an explicitly supplied `FLAG` overrides it.

Use the organizer's original server bundle and deployment configuration to reproduce the original environment. This handout is not a drop-in replacement for that bundle.

## Package layout

The local `app/` and `bot/` directories are packaged as `dist/app/` and `dist/bot/`. The Compose seccomp path points to `dist/bot/seccomp_profile.json`. The root `docker-compose.yml` uses paths relative to this archive. Run Compose from the extracted archive root if inspecting it locally.

Solutions, solver scripts, tests, challenge metadata, and organizer deployment documents are intentionally excluded. Python bytecode caches and local build paths are excluded as well.
