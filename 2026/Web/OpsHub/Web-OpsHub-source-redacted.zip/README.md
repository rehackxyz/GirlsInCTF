# OpsHub — redacted source handout

This archive is a source handout with placeholder credentials. It does not contain the original deployment secrets. Application logic is retained; redacted values change authentication, signatures, and returned data where described below.

## Redacted values

The deployment token in both services, staging and production database passwords, demo login password, displayed demo credentials, and fallback flag are redacted.

`REDACTED` is a literal placeholder, not an instruction to automatically load the original value. Redacted hardcoded credentials and signing keys do not gain environment-variable overrides in this handout.

## Runtime differences

The demo login is `opshub` / `REDACTED`. Metadata and deploy use the same literal `REDACTED` token. Both database password values are placeholders. These credentials differ from the original deployment. The fallback flag is `gctf26{REDACTED}`; an explicitly supplied `FLAG` overrides it.

Use the organizer's original server bundle and deployment configuration to reproduce the original environment. This handout is not a drop-in replacement for that bundle.

## Package layout

The local `edge/`, `metadata/`, and `deploy/` directories are packaged under `dist/`. The root `docker-compose.yml` uses paths relative to this archive. Run Compose from the extracted archive root if inspecting it locally.

Solutions, solver scripts, tests, challenge metadata, and organizer deployment documents are intentionally excluded. Python bytecode caches and local build paths are excluded as well.
